package edu.uob;

public enum DataType{
    DOUBLE,
    STRING;
}
