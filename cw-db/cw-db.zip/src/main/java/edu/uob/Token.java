package edu.uob;

public class Token{
    String tokenText;

    public Token(String tokenText){
        this.tokenText = tokenText;
    }
}
