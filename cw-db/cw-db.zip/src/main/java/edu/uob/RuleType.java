package edu.uob;

public enum RuleType{
    OR, //"OR" rule
    SEQ, //Sequential rule
    TERM; //Terminal rule
}